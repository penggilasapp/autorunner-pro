# AutoRunner Pro — GitHub APK build

## Build APK tanpa Android Studio di HP

1. Buat repositori baru di GitHub.
2. Unggah **isi ZIP ini** ke root repositori (bukan mengunggah ZIP sebagai satu file). Pastikan folder `.github/workflows/` ikut terunggah.
3. Buka tab **Actions**.
4. Pilih **Build AutoRunner Pro Android APK**, lalu tekan **Run workflow**. Jika tab Actions meminta aktivasi workflow, aktifkan terlebih dahulu.
5. Tunggu workflow selesai. Jika hijau, buka hasil run dan unduh artifact **AutoRunner-Pro-debug-apk**.
6. Ekstrak artifact ZIP yang diunduh untuk mendapatkan `app-debug.apk`, lalu instal di Android. Untuk APK debug, Android mungkin meminta izin instal aplikasi dari sumber ini.

## Catatan penting

- Workflow membangun APK debug dari proyek Android pada `extracted_android/PENGGILAS_ZIP_RUNNER_ANDROID`.
- APK belum dianggap berhasil dibuat sampai GitHub Actions selesai dengan status sukses dan artifact dapat diunduh.
- Workflow ini hanya membangun APK. Dukungan kompilasi source React + Vite langsung di Android masih merupakan pekerjaan terpisah dan belum dijamin oleh APK ini.
