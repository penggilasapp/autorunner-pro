import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import http from 'http';
import { execSync, spawn, ChildProcess } from 'child_process';
import JSZip from 'jszip';

const PORT = 3000;
const PROJECTS_BASE = path.join('/tmp', 'zip_runner_projects');

if (!fs.existsSync(PROJECTS_BASE)) {
  fs.mkdirSync(PROJECTS_BASE, { recursive: true });
}

// MIME types dictionary for static files
const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.cjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.pdf': 'application/pdf',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.mp3': 'audio/mpeg',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.ogg': 'audio/ogg',
  '.wav': 'audio/wav',
  '.wasm': 'application/wasm',
  '.csv': 'text/csv; charset=utf-8',
};

// Interface for running backend process
interface ActiveBackend {
  projectId: string;
  child: ChildProcess;
  port: number;
  pid: number;
  startedAt: string;
  logs: string[];
  healthStatus: 'HEALTHY' | 'UNHEALTHY' | 'STOPPED' | 'STARTING';
  serverFile: string;
}

const activeBackends = new Map<string, ActiveBackend>();
let nextBackendPort = 4010;

function allocateBackendPort(): number {
  const port = nextBackendPort;
  nextBackendPort++;
  if (nextBackendPort > 4200) {
    nextBackendPort = 4010;
  }
  return port;
}

// Robust directory containment check against directory traversal attacks
function sanitizePath(baseDir: string, userSubPath: string): string | null {
  const safeSubPath = path.normalize(userSubPath).replace(/^(\.\.[\/\\])+/, '');
  const resolved = path.resolve(baseDir, safeSubPath);
  const resolvedBase = path.resolve(baseDir);
  // Robust containment check: resolved must be inside base or equal to base
  if (resolved !== resolvedBase && !resolved.startsWith(resolvedBase + path.sep)) {
    return null; // attempted traversal
  }
  return resolved;
}

function getBridgeScript(projectId: string): string {
  return `
<script>
(function() {
  if (window.__zipRunnerBridgeInjected) return;
  window.__zipRunnerBridgeInjected = true;
  window.__zipRunnerProjectId = "${projectId}";

  // 1. Console Log Interception for DevTools Inspector
  var origLog = console.log;
  var origWarn = console.warn;
  var origError = console.error;
  var origInfo = console.info;

  function sendLog(level, args) {
    try {
      var str = Array.prototype.slice.call(args).map(function(item) {
        if (typeof item === 'object') {
          try { return JSON.stringify(item); } catch(e) { return String(item); }
        }
        return String(item);
      }).join(' ');

      window.parent.postMessage({
        type: 'ZIP_RUNNER_LOG',
        level: level,
        message: str,
        timestamp: new Date().toLocaleTimeString()
      }, '*');
    } catch(e) {}
  }

  console.log = function() { origLog.apply(console, arguments); sendLog('log', arguments); };
  console.info = function() { origInfo.apply(console, arguments); sendLog('info', arguments); };
  console.warn = function() { origWarn.apply(console, arguments); sendLog('warn', arguments); };
  console.error = function() { origError.apply(console, arguments); sendLog('error', arguments); };

  // 2. Fetch Interceptor for seamless Backend API proxying
  var origFetch = window.fetch;
  window.fetch = function(input, init) {
    var url = typeof input === 'string' ? input : (input && input.url ? input.url : '');
    // If request is made to /api/ or api/, route it through the runner backend proxy for this project
    if (url && (url.indexOf('/api/') === 0 || url.indexOf('api/') === 0)) {
      var clean = url.replace(/^\\/?api\\//, '');
      var proxiedUrl = '/projects/' + window.__zipRunnerProjectId + '/api/' + clean;
      if (typeof input === 'string') {
        input = proxiedUrl;
      } else if (input && input.url) {
        input = new Request(proxiedUrl, init || input);
      }
    }
    return origFetch.apply(window, arguments);
  };

  // 3. ZipRunnerBridge Implementation
  window.ZipRunnerBridge = {
    projectId: "${projectId}",
    printPage: function(pageUrl, html) {
      window.parent.postMessage({
        type: 'ZIP_RUNNER_PRINT',
        pageUrl: pageUrl || window.location.href,
        html: html || ('<!doctype html>' + document.documentElement.outerHTML)
      }, '*');
    },
    savePdf: function(fileName, htmlOrBase64) {
      window.parent.postMessage({
        type: 'ZIP_RUNNER_SAVE_PDF',
        fileName: fileName || ('Laporan_' + Date.now() + '.pdf'),
        content: htmlOrBase64 || ('<!doctype html>' + document.documentElement.outerHTML)
      }, '*');
    },
    saveBase64: function(fileName, mimeType, data) {
      window.parent.postMessage({
        type: 'ZIP_RUNNER_SAVE_BASE64',
        fileName: fileName || 'unduhan',
        mimeType: mimeType || 'application/octet-stream',
        data: data
      }, '*');
    }
  };

  // 4. Hook window.print()
  window.print = function() {
    try {
      var html = '<!doctype html>' + document.documentElement.outerHTML;
      window.ZipRunnerBridge.printPage(String(window.location.href), html);
    } catch (e) {
      console.error('Print request failed', e);
    }
  };

  // 5. Direct PDF export shortcut
  window.exportPdf = function(name) {
    window.ZipRunnerBridge.savePdf(name || ('Laporan_' + Date.now() + '.pdf'));
  };

  // 6. Intercept download links
  document.addEventListener('click', function(ev) {
    var a = ev.target && ev.target.closest ? ev.target.closest('a[download]') : null;
    if (!a) return;
    var href = a.href || '';
    var downloadName = a.download || 'unduhan';

    if (href.indexOf('blob:') === 0 || href.indexOf('data:') === 0) {
      ev.preventDefault();
      window.fetch(href).then(function(r) { return r.blob(); }).then(function(blob) {
        var reader = new FileReader();
        reader.onloadend = function() {
          var res = String(reader.result || '');
          var data = res.split(',')[1] || '';
          var mime = blob.type || (downloadName.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream');
          window.ZipRunnerBridge.saveBase64(downloadName, mime, data);
        };
        reader.readAsDataURL(blob);
      }).catch(function(e) {
        console.error('Download gagal', e);
      });
    }
  }, true);
})();
</script>
`;
}

// Inspect project directory to determine architecture and mode
export interface AnalyzedProject {
  mode: 'static' | 'prebuilt' | 'vite-react' | 'fullstack' | 'unsupported';
  reason: string;
  packageManager: 'npm' | 'bun' | 'yarn' | 'pnpm' | 'none';
  lockfile: string | null;
  pkgJson: any | null;
  serverFile: string | null;
  hasBuildScript: boolean;
  entryHtml: string | null;
  allFiles: string[];
  isPrebuilt: boolean;
}

export function analyzeProject(dir: string): AnalyzedProject {
  const allFiles: string[] = [];
  function scan(current: string, rel: string) {
    const list = fs.readdirSync(current);
    for (const item of list) {
      const full = path.join(current, item);
      const subRel = rel ? `${rel}/${item}` : item;
      if (fs.statSync(full).isDirectory()) {
        scan(full, subRel);
      } else {
        allFiles.push(subRel);
      }
    }
  }
  scan(dir, '');

  let pkgJson: any = null;
  const pkgPath = path.join(dir, 'package.json');
  if (fs.existsSync(pkgPath)) {
    try {
      pkgJson = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
    } catch (e) {
      console.warn('Error reading package.json:', e);
    }
  }

  // Detect lockfile
  let lockfile: string | null = null;
  let packageManager: 'npm' | 'bun' | 'yarn' | 'pnpm' | 'none' = 'none';
  if (allFiles.some((f) => f === 'bun.lock' || f === 'bun.lockb')) {
    lockfile = 'bun.lock';
    packageManager = 'bun';
  } else if (allFiles.some((f) => f === 'package-lock.json')) {
    lockfile = 'package-lock.json';
    packageManager = 'npm';
  } else if (allFiles.some((f) => f === 'yarn.lock')) {
    lockfile = 'yarn.lock';
    packageManager = 'yarn';
  } else if (allFiles.some((f) => f === 'pnpm-lock.yaml')) {
    lockfile = 'pnpm-lock.yaml';
    packageManager = 'pnpm';
  } else if (pkgJson) {
    packageManager = 'npm';
  }

  // Check for server files
  const serverCandidates = ['server.ts', 'server.js', 'src/server.ts', 'src/server.js', 'server/index.ts', 'server/index.js'];
  let serverFile: string | null = null;
  for (const c of serverCandidates) {
    if (fs.existsSync(path.join(dir, c))) {
      serverFile = c;
      break;
    }
  }

  const scripts = pkgJson?.scripts || {};
  const hasBuildScript = Boolean(scripts.build);
  const isServerScript = Boolean(
    (scripts.start && (scripts.start.includes('server') || scripts.start.includes('node') || scripts.start.includes('tsx'))) ||
    (scripts.dev && (scripts.dev.includes('server.ts') || scripts.dev.includes('server.js')))
  );

  const hasReactOrVite = Boolean(
    allFiles.some((f) => f.includes('vite.config') || f.endsWith('.tsx') || f.endsWith('.jsx')) ||
    pkgJson?.dependencies?.vite ||
    pkgJson?.dependencies?.react ||
    pkgJson?.devDependencies?.vite
  );

  // Check if project is prebuilt (e.g. dist/index.html exists and contains built bundles)
  const hasDistIndex = fs.existsSync(path.join(dir, 'dist', 'index.html'));
  const hasRootIndex = fs.existsSync(path.join(dir, 'index.html'));
  let isPrebuilt = false;

  if (hasDistIndex) {
    isPrebuilt = true;
  } else if (hasRootIndex && !hasReactOrVite && allFiles.some((f) => f.startsWith('assets/'))) {
    isPrebuilt = true;
  }

  // Determine mode and reason
  let mode: 'static' | 'prebuilt' | 'vite-react' | 'fullstack' | 'unsupported' = 'static';
  let reason = '';

  if (serverFile && (isServerScript || pkgJson?.dependencies?.express)) {
    mode = 'fullstack';
    reason = `Ditemukan server backend (${serverFile}) dan konfigurasi Express. Memerlukan build frontend dan runtime backend terpisah.`;
  } else if (isPrebuilt) {
    mode = 'prebuilt';
    reason = hasDistIndex
      ? 'Ditemukan folder dist/ dengan bundle index.html terkompilasi siap pakai.'
      : 'Ditemukan struktur aset produksi terkompilasi siap disajikan.';
  } else if (hasReactOrVite || (pkgJson && hasBuildScript)) {
    mode = 'vite-react';
    reason = 'Ditemukan source code React / Vite dengan file TypeScript/JSX. Memerlukan kompilasi bundler ke dist/.';
  } else if (hasRootIndex || allFiles.some((f) => f.endsWith('.html') || f.endsWith('.htm'))) {
    mode = 'static';
    reason = 'Website statis dengan berkas HTML/CSS/JS siap pakai tanpa langkah kompilasi bundler.';
  } else {
    mode = 'unsupported';
    reason = 'Tidak ditemukan berkas HTML atau konfigurasi frontend/backend yang didukung di dalam folder proyek.';
  }

  // Find entry HTML
  let entryHtml: string | null = null;
  if (hasDistIndex) {
    entryHtml = 'dist/index.html';
  } else if (hasRootIndex) {
    entryHtml = 'index.html';
  } else if (fs.existsSync(path.join(dir, 'default.html'))) {
    entryHtml = 'default.html';
  } else {
    const html = allFiles.find((f) => f.endsWith('.html') || f.endsWith('.htm'));
    if (html) entryHtml = html;
  }

  return {
    mode,
    reason,
    packageManager,
    lockfile,
    pkgJson,
    serverFile,
    hasBuildScript,
    entryHtml,
    allFiles,
    isPrebuilt,
  };
}

// Ensure dependencies are ready for build or runtime
function ensureProjectDependencies(srcDir: string, analysis: AnalyzedProject): { success: boolean; installed: string[]; logs: string; error?: string } {
  const rootNm = path.join(process.cwd(), 'node_modules');
  const targetNm = path.join(srcDir, 'node_modules');
  const installed: string[] = [];
  let logs = '';

  // 1. Link root node_modules for instant caching
  if (!fs.existsSync(targetNm) && fs.existsSync(rootNm)) {
    try {
      fs.symlinkSync(rootNm, targetNm, 'junction');
      logs += `[Dependencies] Symlinked core cached node_modules.\n`;
    } catch (e: any) {
      logs += `[Dependencies] Symlink notice: ${e.message}\n`;
    }
  }

  // 2. Check if there are missing packages listed in package.json
  const requiredDeps = {
    ...(analysis.pkgJson?.dependencies || {}),
    ...(analysis.pkgJson?.devDependencies || {}),
  };

  const missing: string[] = [];
  for (const dep of Object.keys(requiredDeps)) {
    const depPath = path.join(targetNm, dep);
    if (!fs.existsSync(depPath)) {
      missing.push(dep);
    }
  }

  if (missing.length > 0) {
    logs += `[Dependencies] Ditemukan ${missing.length} paket belum tersedia: ${missing.join(', ')}\n`;
    logs += `[Dependencies] Memasang paket menggunakan package manager ${analysis.packageManager || 'npm'}...\n`;
    try {
      const pmCmd = analysis.packageManager === 'bun' ? 'bun add' : 'npm install --no-audit --no-fund --save-exact';
      const cmd = `${pmCmd} ${missing.join(' ')}`;
      const out = execSync(cmd, { cwd: srcDir, timeout: 40000, stdio: 'pipe' });
      logs += out.toString() + '\n';
      installed.push(...missing);
    } catch (installErr: any) {
      const errOut = (installErr.stderr || installErr.stdout || installErr.message).toString();
      logs += `[Dependencies Error] ${errOut}\n`;
      return {
        success: false,
        installed,
        logs,
        error: `Gagal memasang dependensi: ${missing.join(', ')}. Detail: ${errOut.slice(0, 300)}`,
      };
    }
  } else {
    logs += `[Dependencies] Seluruh ${Object.keys(requiredDeps).length} dependensi terverifikasi lengkap.\n`;
  }

  return { success: true, installed, logs };
}

// Build Vite/React project and strictly validate dist output
interface BuildResult {
  success: boolean;
  durationMs: number;
  verifiedFilesCount: number;
  assetCount: number;
  totalAssetBytes: number;
  hasIndexHtml: boolean;
  entryHtmlSize: number;
  logs: string;
  error?: string;
}

function buildViteProject(srcDir: string, distTarget: string): BuildResult {
  const startTime = Date.now();
  let logs = '';

  try {
    logs += `[Build] Memulai Vite build: npx vite build --base ./ --outDir "${distTarget}"\n`;
    const buildOutput = execSync(`npx vite build --base ./ --outDir "${distTarget}"`, {
      cwd: srcDir,
      timeout: 50000,
      stdio: 'pipe',
    });
    logs += buildOutput.toString() + '\n';

    const durationMs = Date.now() - startTime;

    // Strict Verification of dist/ output
    if (!fs.existsSync(distTarget)) {
      throw new Error(`Direktori output 'dist/' tidak terbentuk.`);
    }

    const distIndex = path.join(distTarget, 'index.html');
    if (!fs.existsSync(distIndex) || !fs.statSync(distIndex).isFile()) {
      throw new Error(`File 'index.html' tidak ditemukan di dalam 'dist/'.`);
    }

    const entryHtmlSize = fs.statSync(distIndex).size;
    if (entryHtmlSize < 50) {
      throw new Error(`File 'dist/index.html' terlalu kecil (${entryHtmlSize} bytes), kemungkinan build korup.`);
    }

    // Verify assets
    let verifiedFilesCount = 0;
    let assetCount = 0;
    let totalAssetBytes = 0;

    function countAssets(dir: string) {
      const items = fs.readdirSync(dir);
      for (const item of items) {
        const full = path.join(dir, item);
        if (fs.statSync(full).isDirectory()) {
          countAssets(full);
        } else {
          verifiedFilesCount++;
          const sz = fs.statSync(full).size;
          totalAssetBytes += sz;
          if (dir.includes('assets') || item.endsWith('.js') || item.endsWith('.css')) {
            assetCount++;
          }
        }
      }
    }
    countAssets(distTarget);

    logs += `[Build Validation] SUCCESS: ${verifiedFilesCount} berkas terverifikasi di dist/ (${Math.round(totalAssetBytes / 1024)} KB, ${assetCount} assets, entry: ${entryHtmlSize} B).\n`;

    return {
      success: true,
      durationMs,
      verifiedFilesCount,
      assetCount,
      totalAssetBytes,
      hasIndexHtml: true,
      entryHtmlSize,
      logs,
    };
  } catch (err: any) {
    const durationMs = Date.now() - startTime;
    const stderr = err.stderr ? err.stderr.toString() : '';
    const stdout = err.stdout ? err.stdout.toString() : '';
    logs += stdout + '\n' + stderr + '\n' + err.message;
    return {
      success: false,
      durationMs,
      verifiedFilesCount: 0,
      assetCount: 0,
      totalAssetBytes: 0,
      hasIndexHtml: false,
      entryHtmlSize: 0,
      logs,
      error: stderr || stdout || err.message,
    };
  }
}

// Start and supervise backend process for fullstack projects
async function startBackendProcess(projectId: string, projectDir: string, serverFile: string): Promise<ActiveBackend> {
  // If already running, kill first
  if (activeBackends.has(projectId)) {
    const existing = activeBackends.get(projectId)!;
    try {
      existing.child.kill('SIGTERM');
    } catch (e) {}
    activeBackends.delete(projectId);
  }

  const port = allocateBackendPort();
  const logs: string[] = [];

  const child = spawn('npx', ['tsx', serverFile], {
    cwd: projectDir,
    env: {
      ...process.env,
      PORT: String(port),
      NODE_ENV: 'production',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  child.stdout?.on('data', (d) => {
    const line = d.toString().trim();
    if (line) logs.push(`[STDOUT ${new Date().toLocaleTimeString()}] ${line}`);
    if (logs.length > 100) logs.shift();
  });

  child.stderr?.on('data', (d) => {
    const line = d.toString().trim();
    if (line) logs.push(`[STDERR ${new Date().toLocaleTimeString()}] ${line}`);
    if (logs.length > 100) logs.shift();
  });

  const backendRecord: ActiveBackend = {
    projectId,
    child,
    port,
    pid: child.pid || 0,
    startedAt: new Date().toISOString(),
    logs,
    healthStatus: 'STARTING',
    serverFile,
  };

  child.on('exit', (code, signal) => {
    backendRecord.healthStatus = 'STOPPED';
    logs.push(`[Process Exited] Code: ${code}, Signal: ${signal}`);
  });

  activeBackends.set(projectId, backendRecord);

  // Wait up to 5 seconds for backend to become ready
  const isHealthy = await checkPortReadiness(port, 5000);
  backendRecord.healthStatus = isHealthy ? 'HEALTHY' : 'UNHEALTHY';

  return backendRecord;
}

function checkPortReadiness(port: number, timeoutMs: number): Promise<boolean> {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      const req = http.get(`http://127.0.0.1:${port}/api/health`, (res) => {
        if (res.statusCode && res.statusCode < 500) {
          return resolve(true);
        }
        retry();
      });
      req.on('error', () => {
        const rootReq = http.get(`http://127.0.0.1:${port}/`, (res) => {
          return resolve(true);
        });
        rootReq.on('error', retry);
      });
    };

    const retry = () => {
      if (Date.now() - start > timeoutMs) {
        return resolve(false);
      }
      setTimeout(check, 300);
    };

    check();
  });
}

function injectBridgeIntoDir(dir: string, projectId: string) {
  if (!fs.existsSync(dir)) return;
  const bridgeScript = getBridgeScript(projectId);
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) {
      injectBridgeIntoDir(full, projectId);
    } else if (f.endsWith('.html') || f.endsWith('.htm')) {
      try {
        let content = fs.readFileSync(full, 'utf-8');
        if (!content.includes('__zipRunnerBridgeInjected')) {
          if (content.includes('<head>')) {
            content = content.replace('<head>', `<head>${bridgeScript}`);
          } else if (content.includes('<html>')) {
            content = content.replace('<html>', `<html><head>${bridgeScript}</head>`);
          } else {
            content = `${bridgeScript}${content}`;
          }
          fs.writeFileSync(full, content, 'utf-8');
        }
      } catch (e) {
        console.warn('Inject bridge error on', full, e);
      }
    }
  }
}

function addDirToZip(dir: string, zip: JSZip, rootInZip: string) {
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = path.join(dir, f);
    const rel = rootInZip ? `${rootInZip}/${f}` : f;
    if (fs.statSync(full).isDirectory()) {
      addDirToZip(full, zip, rel);
    } else {
      zip.file(rel, fs.readFileSync(full));
    }
  }
}

function countFiles(dir: string): number {
  let count = 0;
  if (!fs.existsSync(dir)) return 0;
  const files = fs.readdirSync(dir);
  for (const f of files) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) {
      count += countFiles(full);
    } else {
      count++;
    }
  }
  return count;
}

async function startServer() {
  const app = express();

  app.use(express.json({ limit: '200mb' }));
  app.use(express.urlencoded({ extended: true, limit: '200mb' }));

  // ==========================================
  // API 1: Quick Analysis Endpoint (Inspects without building)
  // ==========================================
  app.post('/api/analyze-project', async (req: Request, res: Response) => {
    try {
      const { name, zipBase64 } = req.body;
      if (!zipBase64) {
        return res.status(400).json({ error: 'zipBase64 diperlukan untuk analisis' });
      }

      const tempId = `temp_analyze_${Date.now()}`;
      const tempDir = path.join('/tmp', tempId);
      fs.mkdirSync(tempDir, { recursive: true });

      const buffer = Buffer.from(zipBase64, 'base64');
      const zip = new JSZip();
      const zipContent = await zip.loadAsync(buffer);

      for (const [relativePath, file] of Object.entries(zipContent.files)) {
        if (file.dir) continue;
        const normalized = relativePath.replace(/\\/g, '/').replace(/^\/+/, '');
        if (normalized.includes('..')) continue;

        const filePath = path.join(tempDir, normalized);
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        const content = await file.async('nodebuffer');
        fs.writeFileSync(filePath, content);
      }

      const analysis = analyzeProject(tempDir);
      // Clean up temp dir
      try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (e) {}

      return res.json({
        success: true,
        analysis: {
          mode: analysis.mode,
          reason: analysis.reason,
          packageManager: analysis.packageManager,
          lockfile: analysis.lockfile,
          dependencies: analysis.pkgJson?.dependencies || {},
          devDependencies: analysis.pkgJson?.devDependencies || {},
          scripts: analysis.pkgJson?.scripts || {},
          hasServerFile: Boolean(analysis.serverFile),
          serverFile: analysis.serverFile,
          entryHtml: analysis.entryHtml,
          runtimeVersion: process.version,
          isPrebuilt: analysis.isPrebuilt,
        },
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Gagal menganalisis proyek' });
    }
  });

  // ==========================================
  // API 2: Run Project from ZIP Base64 or Folder
  // ==========================================
  app.post('/api/run-project', async (req: Request, res: Response) => {
    try {
      const { name, zipBase64 } = req.body;
      if (!zipBase64) {
        return res.status(400).json({ error: 'zipBase64 is required' });
      }

      const cleanName = (name || 'project')
        .replace(/[^a-zA-Z0-9_-]/g, '_')
        .slice(0, 30);
      const projectId = `proj_${Date.now()}_${cleanName}`;
      const projectDir = path.join(PROJECTS_BASE, projectId);
      const srcDir = path.join(projectDir, 'src_extracted');
      const distDir = path.join(projectDir, 'dist');
      const publicDir = path.join(projectDir, 'public');

      fs.mkdirSync(srcDir, { recursive: true });

      // Unpack ZIP with strict path sanitization
      const buffer = Buffer.from(zipBase64, 'base64');
      const zip = new JSZip();
      const zipContent = await zip.loadAsync(buffer);

      for (const [relativePath, file] of Object.entries(zipContent.files)) {
        if (file.dir) continue;
        const normalized = relativePath.replace(/\\/g, '/').replace(/^\/+/, '');
        // Strict path traversal containment check
        const safePath = sanitizePath(srcDir, normalized);
        if (!safePath) continue;

        fs.mkdirSync(path.dirname(safePath), { recursive: true });
        const content = await file.async('nodebuffer');
        fs.writeFileSync(safePath, content);
      }

      // Step 1: Analyze project structure
      const analysis = analyzeProject(srcDir);
      console.log(`[PENGGILAS RUNNER] Proyek ${name}: mode=${analysis.mode}, pm=${analysis.packageManager}, lock=${analysis.lockfile}`);

      if (analysis.mode === 'unsupported') {
        return res.status(422).json({
          success: false,
          status: 'UNSUPPORTED',
          mode: 'unsupported',
          error: analysis.reason,
          analysis,
        });
      }

      // Activity timeline
      const activitySteps = [
        { id: '1_structure', title: 'Memeriksa struktur proyek', status: 'success', message: analysis.reason },
        { id: '2_dependencies', title: 'Menyiapkan dependensi', status: 'pending' },
        { id: '3_build', title: 'Membangun frontend', status: 'pending' },
        { id: '4_backend', title: 'Memulai backend', status: 'pending' },
        { id: '5_server_ready', title: 'Memeriksa kesiapan server', status: 'pending' },
        { id: '6_launch', title: 'Membuka aplikasi', status: 'pending' },
      ];

      // Step 2: Prepare dependencies if needed
      let depResult: any = { success: true, installed: [], logs: '' };
      if (analysis.mode === 'vite-react' || analysis.mode === 'fullstack') {
        activitySteps[1].status = 'running';
        depResult = ensureProjectDependencies(srcDir, analysis);
        if (!depResult.success) {
          activitySteps[1].status = 'failed';
          activitySteps[1].message = depResult.error;
          return res.status(422).json({
            success: false,
            status: 'FAILED',
            mode: analysis.mode,
            error: depResult.error,
            activitySteps,
            analysis,
          });
        }
        activitySteps[1].status = 'success';
        activitySteps[1].message = depResult.installed.length > 0
          ? `Berhasil memasang ${depResult.installed.length} dependensi.`
          : 'Semua dependensi terverifikasi lengkap dari cache.';
      } else {
        activitySteps[1].status = 'skipped';
        activitySteps[1].message = 'Tidak diperlukan (Website statis / pre-built).';
      }

      let buildValidation: BuildResult | null = null;
      let startPage = 'index.html';
      let isCompiled = false;
      let backendInfo: any = null;

      // Step 3: Frontend Build
      if (analysis.mode === 'vite-react' || analysis.mode === 'fullstack') {
        activitySteps[2].status = 'running';
        buildValidation = buildViteProject(srcDir, distDir);

        if (!buildValidation.success) {
          activitySteps[2].status = 'failed';
          activitySteps[2].message = 'Proses build Vite gagal.';
          return res.status(422).json({
            success: false,
            status: 'FAILED',
            mode: analysis.mode,
            error: buildValidation.error || 'Vite build compilation failed',
            buildLogs: buildValidation.logs,
            activitySteps,
            analysis,
            buildValidation,
          });
        }

        fs.cpSync(distDir, publicDir, { recursive: true });
        isCompiled = true;
        activitySteps[2].status = 'success';
        activitySteps[2].message = `Build berhasil dalam ${buildValidation.durationMs}ms (${buildValidation.verifiedFilesCount} berkas, ${Math.round(buildValidation.totalAssetBytes / 1024)} KB).`;
      } else if (analysis.mode === 'prebuilt' && fs.existsSync(path.join(srcDir, 'dist'))) {
        fs.cpSync(path.join(srcDir, 'dist'), publicDir, { recursive: true });
        isCompiled = true;
        activitySteps[2].status = 'skipped';
        activitySteps[2].message = 'Menggunakan hasil build dist/ yang sudah ada di arsip.';
        buildValidation = {
          success: true,
          durationMs: 0,
          verifiedFilesCount: countFiles(publicDir),
          assetCount: 0,
          totalAssetBytes: 0,
          hasIndexHtml: fs.existsSync(path.join(publicDir, 'index.html')),
          entryHtmlSize: fs.existsSync(path.join(publicDir, 'index.html')) ? fs.statSync(path.join(publicDir, 'index.html')).size : 0,
          logs: '[Prebuilt] Menggunakan paket hasil kompilasi yang disertakan.',
        };
      } else {
        // Static mode
        fs.cpSync(srcDir, publicDir, { recursive: true });
        activitySteps[2].status = 'skipped';
        activitySteps[2].message = 'Tidak diperlukan untuk website statis.';
        buildValidation = {
          success: true,
          durationMs: 0,
          verifiedFilesCount: countFiles(publicDir),
          assetCount: 0,
          totalAssetBytes: 0,
          hasIndexHtml: fs.existsSync(path.join(publicDir, 'index.html')),
          entryHtmlSize: fs.existsSync(path.join(publicDir, 'index.html')) ? fs.statSync(path.join(publicDir, 'index.html')).size : 0,
          logs: '[Static] Website disajikan langsung dari file statis.',
        };
      }

      // Step 4 & 5: Backend Process & Server Ready
      if (analysis.mode === 'fullstack' && analysis.serverFile) {
        activitySteps[3].status = 'running';
        activitySteps[4].status = 'running';

        const backend = await startBackendProcess(projectId, srcDir, analysis.serverFile);
        backendInfo = {
          isRunning: backend.healthStatus === 'HEALTHY',
          pid: backend.pid,
          port: backend.port,
          statusText: backend.healthStatus === 'HEALTHY' ? 'OPERATIONAL' : 'STARTING / UNHEALTHY',
          healthStatus: backend.healthStatus,
          healthUrl: `/projects/${projectId}/api/health`,
          recentLogs: backend.logs,
        };

        if (backend.healthStatus === 'HEALTHY') {
          activitySteps[3].status = 'success';
          activitySteps[3].message = `Server Express berjalan pada port lokal ${backend.port} (PID ${backend.pid}).`;
          activitySteps[4].status = 'success';
          activitySteps[4].message = 'Health check backend responsif (200 OK).';
        } else {
          activitySteps[3].status = 'success';
          activitySteps[3].message = `Server Express dimulai pada port ${backend.port}.`;
          activitySteps[4].status = 'failed';
          activitySteps[4].message = 'Health check port belum menjawab dalam batas waktu 5 detik.';
        }
      } else {
        activitySteps[3].status = 'skipped';
        activitySteps[3].message = 'Tidak diperlukan (Proyek frontend murni).';
        activitySteps[4].status = 'skipped';
        activitySteps[4].message = 'Tidak diperlukan.';
      }

      // Step 6: Launch
      injectBridgeIntoDir(publicDir, projectId);

      if (fs.existsSync(path.join(publicDir, 'index.html'))) {
        startPage = 'index.html';
      } else if (fs.existsSync(path.join(publicDir, 'default.html'))) {
        startPage = 'default.html';
      } else {
        const found = fs.readdirSync(publicDir).find((f) => f.endsWith('.html') || f.endsWith('.htm'));
        if (found) startPage = found;
      }

      activitySteps[5].status = 'success';
      activitySteps[5].message = `Aplikasi siap dibuka di ${startPage} (${countFiles(publicDir)} berkas).`;

      // Create clean distribution ZIP of built output for Android Studio assets/web/
      const readyZip = new JSZip();
      addDirToZip(publicDir, readyZip, '');
      const readyZipBuf = await readyZip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
      fs.writeFileSync(path.join(projectDir, 'ready_app.zip'), readyZipBuf);

      return res.json({
        success: true,
        projectId,
        name: name || 'Proyek ZIP',
        mode: analysis.mode,
        startPage,
        url: `/projects/${projectId}/${startPage}`,
        entryCount: countFiles(publicDir),
        fileSize: buffer.length,
        isCompiled,
        activitySteps,
        analysis: {
          mode: analysis.mode,
          reason: analysis.reason,
          packageManager: analysis.packageManager,
          lockfile: analysis.lockfile,
          dependencies: analysis.pkgJson?.dependencies || {},
          devDependencies: analysis.pkgJson?.devDependencies || {},
          scripts: analysis.pkgJson?.scripts || {},
          hasServerFile: Boolean(analysis.serverFile),
          serverFile: analysis.serverFile,
          runtimeVersion: process.version,
        },
        buildValidation,
        backendInfo,
      });
    } catch (err: any) {
      console.error('[PENGGILAS RUNNER] Run project error:', err);
      return res.status(500).json({ error: err.message || 'Gagal memproses proyek' });
    }
  });

  // ==========================================
  // API 3: Backend Process Control
  // ==========================================
  app.get('/api/projects/:projectId/backend-status', (req: Request, res: Response) => {
    const { projectId } = req.params;
    const backend = activeBackends.get(projectId);
    if (!backend) {
      return res.json({ isRunning: false, statusText: 'NOT_RUNNING', logs: [] });
    }
    return res.json({
      isRunning: backend.healthStatus === 'HEALTHY' || backend.healthStatus === 'STARTING',
      pid: backend.pid,
      port: backend.port,
      healthStatus: backend.healthStatus,
      statusText: backend.healthStatus,
      recentLogs: backend.logs,
    });
  });

  app.post('/api/projects/:projectId/stop-backend', (req: Request, res: Response) => {
    const { projectId } = req.params;
    const backend = activeBackends.get(projectId);
    if (backend) {
      try {
        backend.child.kill('SIGTERM');
        setTimeout(() => {
          try { backend.child.kill('SIGKILL'); } catch (e) {}
        }, 1500);
      } catch (e) {}
      activeBackends.delete(projectId);
      return res.json({ success: true, message: `Backend process PID ${backend.pid} dihentikan.` });
    }
    return res.json({ success: true, message: 'Tidak ada backend aktif untuk proyek ini.' });
  });

  // Proxy test endpoint to verify API response
  app.all('/api/projects/:projectId/test-api', (req: Request, res: Response) => {
    const { projectId } = req.params;
    const backend = activeBackends.get(projectId);
    if (!backend) {
      return res.status(404).json({ error: 'Backend process is not running for this project.' });
    }

    const testPath = (req.query.path as string) || '/api/health';
    const clientReq = http.request(
      {
        hostname: '127.0.0.1',
        port: backend.port,
        path: testPath,
        method: req.method,
        headers: {
          'Content-Type': 'application/json',
        },
      },
      (backendRes) => {
        let body = '';
        backendRes.on('data', (c) => (body += c));
        backendRes.on('end', () => {
          try {
            res.status(backendRes.statusCode || 200).json(JSON.parse(body));
          } catch (e) {
            res.status(backendRes.statusCode || 200).send(body);
          }
        });
      }
    );

    clientReq.on('error', (err) => {
      res.status(502).json({ error: `Backend proxy connection failed: ${err.message}` });
    });

    if (req.method !== 'GET' && req.body) {
      clientReq.write(JSON.stringify(req.body));
    }
    clientReq.end();
  });

  // ==========================================
  // API 4: Download Ready Project ZIP
  // ==========================================
  app.get('/api/download-project/:projectId', (req: Request, res: Response) => {
    const { projectId } = req.params;
    const zipPath = path.join(PROJECTS_BASE, projectId, 'ready_app.zip');
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${projectId}-android-ready.zip"`);
      return fs.createReadStream(zipPath).pipe(res);
    }
    return res.status(404).send('Project ZIP not found');
  });

  // ==========================================
  // Route 5: Reverse Proxy for Backend API calls (/projects/:projectId/api/*)
  // ==========================================
  app.all('/projects/:projectId/api/*', (req: Request, res: Response, next: NextFunction) => {
    const { projectId } = req.params;
    const backend = activeBackends.get(projectId);
    if (!backend) {
      return next(); // Not a running backend, pass to static handler
    }

    // Rewrite URL to target backend port: /projects/:projectId/api/... -> /api/...
    const subApiPath = req.originalUrl.replace(new RegExp(`^/projects/${projectId}`), '');

    const clientReq = http.request(
      {
        hostname: '127.0.0.1',
        port: backend.port,
        path: subApiPath,
        method: req.method,
        headers: {
          ...req.headers,
          host: `127.0.0.1:${backend.port}`,
        },
      },
      (backendRes) => {
        res.writeHead(backendRes.statusCode || 200, backendRes.headers);
        backendRes.pipe(res);
      }
    );

    clientReq.on('error', (err) => {
      console.error(`[API Proxy Error]`, err.message);
      if (!res.headersSent) {
        res.status(502).json({ error: `Backend proxy error: ${err.message}` });
      }
    });

    req.pipe(clientReq);
  });

  // ==========================================
  // Route 6: Static File Server (/projects/:projectId/*)
  // ==========================================
  app.use('/projects/:projectId', (req: Request, res: Response, next: NextFunction) => {
    const { projectId } = req.params;
    const projectPublicDir = path.join(PROJECTS_BASE, projectId, 'public');
    if (!fs.existsSync(projectPublicDir)) {
      return next();
    }

    const subPath = req.path.replace(/^\/+/, '') || 'index.html';
    const filePath = sanitizePath(projectPublicDir, subPath);

    if (filePath && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const mime = MIME_TYPES[ext] || 'application/octet-stream';
      res.setHeader('Content-Type', mime);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'no-cache');
      return fs.createReadStream(filePath).pipe(res);
    }

    // Clean subpath without query/hash
    const cleanSub = subPath.split('?')[0].split('#')[0];
    const cleanFilePath = sanitizePath(projectPublicDir, cleanSub);
    if (cleanFilePath && fs.existsSync(cleanFilePath) && fs.statSync(cleanFilePath).isFile()) {
      const ext = path.extname(cleanFilePath).toLowerCase();
      const mime = MIME_TYPES[ext] || 'application/octet-stream';
      res.setHeader('Content-Type', mime);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'no-cache');
      return fs.createReadStream(cleanFilePath).pipe(res);
    }

    return next();
  });

  // Fallback for absolute asset paths requested by scripts inside an iframe (e.g. /assets/... or /bazi-data.js)
  app.use((req: Request, res: Response, next: NextFunction) => {
    const referer = req.headers.referer || '';
    const match = referer.match(/\/projects\/([^/?#]+)/);
    if (match) {
      const projectId = match[1];
      const projectDir = path.join(PROJECTS_BASE, projectId, 'public');
      const cleanPath = req.path.replace(/^\/+/, '').split('?')[0].split('#')[0];
      const candidatePath = sanitizePath(projectDir, cleanPath);
      if (candidatePath && fs.existsSync(candidatePath) && fs.statSync(candidatePath).isFile()) {
        const ext = path.extname(candidatePath).toLowerCase();
        const mime = MIME_TYPES[ext] || 'application/octet-stream';
        res.setHeader('Content-Type', mime);
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Cache-Control', 'no-cache');
        return fs.createReadStream(candidatePath).pipe(res);
      }
    }
    next();
  });

  // Mount Vite in dev mode or static files in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static('dist'));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  // Graceful cleanup on termination
  process.on('SIGTERM', () => {
    for (const [id, backend] of activeBackends.entries()) {
      try { backend.child.kill('SIGKILL'); } catch (e) {}
    }
    process.exit(0);
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[PENGGILAS ZIP RUNNER Server] Active and listening at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[PENGGILAS ZIP RUNNER Server] Startup failed:', err);
});
