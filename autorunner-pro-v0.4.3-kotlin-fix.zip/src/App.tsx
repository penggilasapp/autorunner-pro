import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Printer,
  CheckCircle,
  AlertCircle,
  Code,
  FileCode,
  Download
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { LoadedProject, PhoneSettings, RunnerLogItem, ActivityStep } from './types/runner';
import { loadZipProject, loadHtmlDirectly, loadFolderDirectly } from './utils/zipEngine';
import { Header } from './components/Header';
import { DashboardCards } from './components/DashboardCards';
import { ProjectPicker } from './components/ProjectPicker';
import { ProjectConfigPanel } from './components/ProjectConfigPanel';
import { ExecutionControls } from './components/ExecutionControls';
import { ActivityTimeline } from './components/ActivityTimeline';
import { LogConsole } from './components/LogConsole';
import { PhoneSimulator } from './components/PhoneSimulator';
import { AutomationScriptsModal } from './components/AutomationScriptsModal';
import { FileSystemDrawer } from './components/FileSystemDrawer';
import { PdfExportModal } from './components/PdfExportModal';
import { HtmlEditorModal } from './components/HtmlEditorModal';

export default function App() {
  const [project, setProject] = useState<LoadedProject | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(false); // Light theme is default!
  const [toastMsg, setToastMsg] = useState<{ title: string; desc: string; type: 'info' | 'success' | 'print' } | null>(null);
  const [logs, setLogs] = useState<RunnerLogItem[]>([]);
  const [activitySteps, setActivitySteps] = useState<ActivityStep[]>([
    { id: '1_structure', title: 'Memeriksa struktur proyek', status: 'pending' },
    { id: '2_dependencies', title: 'Menyiapkan dependensi', status: 'pending' },
    { id: '3_build', title: 'Membangun frontend', status: 'pending' },
    { id: '4_backend', title: 'Memulai backend', status: 'pending' },
    { id: '5_server_ready', title: 'Memeriksa kesiapan server', status: 'pending' },
    { id: '6_launch', title: 'Membuka aplikasi', status: 'pending' },
  ]);
  const [errorDetails, setErrorDetails] = useState<{ title: string; message: string; logs?: string } | null>(null);

  // Modals state
  const [isAutomationOpen, setIsAutomationOpen] = useState<boolean>(false);
  const [isFilesDrawerOpen, setIsFilesDrawerOpen] = useState<boolean>(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [isHtmlEditorOpen, setIsHtmlEditorOpen] = useState<boolean>(false);
  const [capturedHtml, setCapturedHtml] = useState<string | undefined>(undefined);

  // Hidden file inputs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  // Helper to add structured runner logs
  const addLog = (level: 'info' | 'warn' | 'error', message: string, source: 'engine' | 'build' | 'backend' | 'webview' = 'engine') => {
    const newLog: RunnerLogItem = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      level,
      message,
      timestamp: new Date().toLocaleTimeString(),
      source,
    };
    setLogs((prev) => [newLog, ...prev.slice(0, 199)]);
  };

  // Detect mobile
  const isMobileDevice = () => {
    if (typeof window === 'undefined') return false;
    return (
      window.innerWidth < 768 ||
      /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    );
  };

  // Phone settings — automatically immersive & fullscreen on mobile devices without user intervention
  const [settings, setSettings] = useState<PhoneSettings>(() => {
    const isMobile = typeof window !== 'undefined' && (
      window.innerWidth < 768 ||
      /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    );
    return {
      deviceType: 'android-flagship',
      isLandscape: false,
      immersiveMode: true,
      showDeviceFrame: !isMobile,
      autoFullscreenOnZip: true,
      autoInjectDependencies: true,
      networkOffline: false,
    };
  });

  useEffect(() => {
    const applyMobileFullscreen = () => {
      if (isMobileDevice()) {
        setSettings((prev) => ({ ...prev, immersiveMode: true, showDeviceFrame: false }));
      }
    };
    applyMobileFullscreen();
    window.addEventListener('resize', applyMobileFullscreen);
    return () => window.removeEventListener('resize', applyMobileFullscreen);
  }, []);

  // Listen for messages from inside the iframe (ZipRunnerBridge & Console interception)
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const data = event.data;
      if (!data || typeof data !== 'object') return;

      if (data.type === 'ZIP_RUNNER_LOG') {
        const lvl = data.level === 'error' ? 'error' : data.level === 'warn' ? 'warn' : 'info';
        addLog(lvl, data.message || '', 'webview');
      } else if (data.type === 'ZIP_RUNNER_PRINT') {
        setCapturedHtml(data.html);
        setIsPdfModalOpen(true);
        showToast('🖨️ Permintaan Cetak Diterima', 'Membuka dialog cetak & ekspor PDF laporan...', 'print');
      } else if (data.type === 'ZIP_RUNNER_SAVE_PDF') {
        setCapturedHtml(data.content);
        setIsPdfModalOpen(true);
        showToast('📥 Ekspor PDF Langsung', `Menyiapkan berkas: ${data.fileName}`, 'success');
      } else if (data.type === 'ZIP_RUNNER_SAVE_BASE64') {
        handleSaveBase64(data.fileName, data.mimeType, data.data);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const showToast = (title: string, desc: string, type: 'info' | 'success' | 'print' = 'info') => {
    setToastMsg({ title, desc, type });
    setTimeout(() => setToastMsg(null), 4000);
  };

  const handleSaveBase64 = (fileName: string, mimeType: string, base64Data: string) => {
    try {
      const cleanData = (base64Data || '').replace(/\s/g, '');
      const byteChars = atob(cleanData);
      const byteNumbers = new Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) {
        byteNumbers[i] = byteChars.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      showToast('✅ Berkas Berhasil Disimpan', `Tersimpan ke folder Download: ${fileName}`, 'success');
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.85 } });
    } catch (e: any) {
      showToast('❌ Gagal Menyimpan Berkas', e.message || 'Format tidak valid', 'info');
    }
  };

  // Convert File or Blob to base64
  const fileToBase64 = (file: Blob | File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const res = reader.result as string;
        const b64 = res.split(',')[1] || res;
        resolve(b64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Execute project run pipeline via backend server
  const executeProjectRun = async (blobOrFile: Blob | File, name: string) => {
    setLoading(true);
    setErrorDetails(null);
    addLog('info', `Memulai eksekusi proyek: ${name}...`, 'engine');

    try {
      const zipBase64 = await fileToBase64(blobOrFile);
      const resp = await fetch('/api/run-project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, zipBase64 }),
      });

      const result = await resp.json();

      if (!resp.ok || !result.success) {
        const errText = result.error || 'Eksekusi proyek gagal.';
        addLog('error', `Build gagal: ${errText}`, 'build');
        setErrorDetails({
          title: 'Kompilasi atau Eksekusi Gagal',
          message: errText,
          logs: result.buildLogs || result.error,
        });
        if (result.activitySteps) {
          setActivitySteps(result.activitySteps);
        }
        showToast('❌ Eksekusi Gagal', errText, 'info');
        return;
      }

      // Success
      if (result.activitySteps) {
        setActivitySteps(result.activitySteps);
      }

      setProject({
        fileName: result.name || name,
        fileSize: result.fileSize || blobOrFile.size,
        entryCount: result.entryCount || 1,
        startPage: result.startPage || 'index.html',
        entries: new Map(),
        indexUrl: result.url,
        loadedAt: new Date(),
        rawZipBlob: blobOrFile,
        projectId: result.projectId,
        mode: result.mode,
        isCompiled: result.isCompiled,
        analysis: result.analysis,
        buildValidation: result.buildValidation,
        backendInfo: result.backendInfo,
        activitySteps: result.activitySteps,
      });

      addLog('info', `Proyek ${name} berhasil dijalankan dalam mode ${result.mode} (${result.entryCount} berkas).`, 'engine');
      if (result.backendInfo?.isRunning) {
        addLog('info', `Backend Express aktif pada port ${result.backendInfo.port} (PID ${result.backendInfo.pid}).`, 'backend');
      }

      showToast(
        result.mode === 'fullstack' ? '🚀 Full-Stack Siap!' : '⚡ Aplikasi Siap!',
        `Dibuka di: ${result.startPage}`,
        'success'
      );
      confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
    } catch (err: any) {
      addLog('error', `Gagal memproses proyek: ${err.message}`, 'engine');
      setErrorDetails({
        title: 'Kesalahan Sistem Runner',
        message: err.message,
      });
      showToast('❌ Kesalahan', err.message, 'info');
    } finally {
      setLoading(false);
    }
  };

  // Quick analysis of project
  const handleAnalyzeProject = async () => {
    if (!project?.rawZipBlob) return;
    setLoading(true);
    addLog('info', `Menganalisis konfigurasi proyek: ${project.fileName}...`, 'engine');
    try {
      const zipBase64 = await fileToBase64(project.rawZipBlob);
      const resp = await fetch('/api/analyze-project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: project.fileName, zipBase64 }),
      });
      const data = await resp.json();
      if (data.success && data.analysis) {
        setProject((prev) => (prev ? { ...prev, analysis: data.analysis, mode: data.analysis.mode } : null));
        addLog('info', `Hasil analisis: ${data.analysis.reason}`, 'engine');
        showToast('🔍 Analisis Selesai', data.analysis.reason, 'info');
      }
    } catch (e: any) {
      addLog('warn', `Analisis gagal: ${e.message}`, 'engine');
    } finally {
      setLoading(false);
    }
  };

  // Handle ZIP file selection
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const lower = file.name.toLowerCase();
    if (lower.endsWith('.html') || lower.endsWith('.htm')) {
      await processDirectHtml(file, file.name);
    } else {
      await executeProjectRun(file, file.name);
    }
    e.target.value = '';
  };

  // Handle directory folder selection
  const handleFolderSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setLoading(true);
    setErrorDetails(null);
    try {
      addLog('info', `Membaca folder proyek lokal (${files.length} berkas)...`, 'engine');
      const loaded = await loadFolderDirectly(files, {
        autoInjectDependencies: settings.autoInjectDependencies,
      });
      // Run the virtual zip generated from folder through the runner pipeline
      await executeProjectRun(loaded.rawZipBlob, loaded.fileName);
    } catch (err: any) {
      addLog('error', `Gagal membuka folder: ${err.message}`, 'engine');
      setErrorDetails({ title: 'Gagal Membuka Folder', message: err.message });
      showToast('❌ Gagal Membuka Folder', err.message, 'info');
    } finally {
      setLoading(false);
      e.target.value = '';
    }
  };

  // Run raw HTML directly
  const processDirectHtml = async (fileOrText: File | string, name: string = 'index.html') => {
    setLoading(true);
    setErrorDetails(null);
    try {
      const loaded = await loadHtmlDirectly(fileOrText, name, {
        autoInjectDependencies: settings.autoInjectDependencies,
      });
      await executeProjectRun(loaded.rawZipBlob, name);
    } catch (err: any) {
      addLog('error', `Gagal menjalankan HTML: ${err.message}`, 'engine');
      setErrorDetails({ title: 'Gagal Menjalankan HTML', message: err.message });
    } finally {
      setLoading(false);
    }
  };

  // Stop running project backend
  const handleStopProject = async () => {
    if (!project?.projectId) {
      setProject(null);
      return;
    }
    try {
      addLog('info', 'Menghentikan proses backend proyek...', 'backend');
      const resp = await fetch(`/api/projects/${project.projectId}/stop-backend`, { method: 'POST' });
      const data = await resp.json();
      addLog('info', data.message || 'Backend dihentikan.', 'backend');
      setProject((prev) => prev ? {
        ...prev,
        backendInfo: prev.backendInfo ? { ...prev.backendInfo, isRunning: false, statusText: 'STOPPED' } : undefined,
      } : null);
      showToast('🛑 Proyek Dihentikan', 'Layanan backend telah dimatikan.', 'info');
    } catch (e: any) {
      addLog('warn', `Gagal menghentikan backend: ${e.message}`, 'backend');
    }
  };

  // Test fullstack API endpoint
  const handleTestApi = async () => {
    if (!project?.projectId) return;
    try {
      addLog('info', 'Mengirim HTTP request: GET /api/health...', 'engine');
      const resp = await fetch(`/api/projects/${project.projectId}/test-api?path=/api/health`);
      const body = await resp.json();
      addLog('info', `Respons API: ${JSON.stringify(body)}`, 'backend');
      showToast('✅ Respons Backend 200 OK', 'API Express aktif dan menjawab dengan benar.', 'success');
    } catch (e: any) {
      addLog('error', `Panggilan API gagal: ${e.message}`, 'backend');
      showToast('❌ Panggilan API Gagal', e.message, 'info');
    }
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} flex flex-col font-sans transition-colors duration-200 antialiased selection:bg-indigo-500/20 selection:text-indigo-900`}>
      {/* Hidden File & Folder Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".zip,.html,.htm,application/zip,application/x-zip-compressed,text/html,application/xhtml+xml,application/octet-stream"
        onChange={handleFileSelect}
        className="hidden"
      />
      <input
        ref={folderInputRef}
        type="file"
        // @ts-expect-error webkitdirectory is standard in modern browsers
        webkitdirectory=""
        directory=""
        multiple
        onChange={handleFolderSelect}
        className="hidden"
      />

      {/* Header */}
      <Header
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenAutomation={() => setIsAutomationOpen(true)}
        activeProjectName={project?.fileName}
        projectId={project?.projectId}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col items-center">
        {/* Dashboard Title & Intro */}
        <div className="w-full text-left mb-6">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
            Project Runner
          </h2>
          <p className="text-sm sm:text-base text-slate-500 mt-1">
            Jalankan website dan aplikasi full-stack dari proyek lokal.
          </p>
        </div>

        {/* Dashboard Metric Cards */}
        <DashboardCards
          project={project}
          isRunning={Boolean(project?.indexUrl)}
        />

        {/* Project Picker (Big Prominent Panel) */}
        <ProjectPicker
          project={project}
          onOpenFolderPicker={() => folderInputRef.current?.click()}
          onOpenFilePicker={() => fileInputRef.current?.click()}
          onOpenPasteCode={() => setIsHtmlEditorOpen(true)}
          onResetProject={() => {
            handleStopProject();
            setProject(null);
            setErrorDetails(null);
          }}
          loading={loading}
        />

        {/* Detection & Configuration Panel (Only if project selected) */}
        {project && (
          <ProjectConfigPanel project={project} />
        )}

        {/* Execution Controls (Analisis, Jalankan, Buka Aplikasi, Hentikan) */}
        <ExecutionControls
          project={project}
          loading={loading}
          onAnalyze={handleAnalyzeProject}
          onRun={() => {
            if (project?.rawZipBlob) {
              executeProjectRun(project.rawZipBlob, project.fileName);
            }
          }}
          onOpenApp={() => {
            if (project?.indexUrl) {
              window.open(project.indexUrl, '_blank', 'noopener,noreferrer');
            }
          }}
          onStop={handleStopProject}
          onTestApi={handleTestApi}
        />

        {/* Activity Timeline (6 Pipeline Steps) */}
        <ActivityTimeline steps={activitySteps} />

        {/* Running Application Stage & Android WebView Simulator */}
        <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-4 sm:p-6 shadow-xs mb-6 flex flex-col items-center">
          <div className="w-full flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${project ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></span>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900 uppercase tracking-wider">
                Simulator Tampilan WebView Android
              </h4>
            </div>
            {project?.indexUrl && (
              <span className="text-[11px] text-slate-500">
                127.0.0.1 • Mode Immersive Penuh
              </span>
            )}
          </div>

          <PhoneSimulator
            project={project}
            settings={settings}
            onUpdateSettings={(newSet) => setSettings((prev) => ({ ...prev, ...newSet }))}
            onPrintRequest={() => setIsPdfModalOpen(true)}
            onOpenFiles={() => setIsFilesDrawerOpen(true)}
            onCloseProject={() => setProject(null)}
            onOpenFilePicker={() => fileInputRef.current?.click()}
            onOpenFolderPicker={() => folderInputRef.current?.click()}
            onOpenPasteCode={() => setIsHtmlEditorOpen(true)}
          />
        </div>

        {/* Log & Diagnostic Console with level filters */}
        <LogConsole
          logs={logs}
          onClearLogs={() => setLogs([])}
          errorDetails={errorDetails}
        />
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 px-4 sm:px-8 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>PENGGILAS ZIP RUNNER PRO • Production-Grade Web & Android WebView Engine</span>
          <span>Node.js v22 • Vite 8 • Express 4 • Strict Sandbox Validation</span>
        </div>
      </footer>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 p-4 bg-slate-900 text-white rounded-2xl shadow-xl backdrop-blur-md max-w-sm animate-slide-up">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
              toastMsg.type === 'success'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : toastMsg.type === 'print'
                ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
            }`}
          >
            {toastMsg.type === 'success' ? (
              <CheckCircle className="w-5 h-5" />
            ) : toastMsg.type === 'print' ? (
              <Printer className="w-5 h-5" />
            ) : (
              <Sparkles className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="font-bold text-xs">{toastMsg.title}</div>
            <div className="text-[11px] text-slate-300">{toastMsg.desc}</div>
          </div>
        </div>
      )}

      {/* Modals */}
      <AutomationScriptsModal
        isOpen={isAutomationOpen}
        onClose={() => setIsAutomationOpen(false)}
      />

      <HtmlEditorModal
        isOpen={isHtmlEditorOpen}
        onClose={() => setIsHtmlEditorOpen(false)}
        onRunHtml={(html, title) => processDirectHtml(html, title)}
      />

      <FileSystemDrawer
        isOpen={isFilesDrawerOpen}
        onClose={() => setIsFilesDrawerOpen(false)}
        project={project}
        onSelectPage={(path) => {
          const entry = project?.entries.get(path);
          if (entry?.url) {
            setProject((prev) => (prev ? { ...prev, indexUrl: entry.url! } : null));
            setIsFilesDrawerOpen(false);
            showToast('📄 Berpindah Halaman', `Membuka ${path}`, 'info');
          }
        }}
      />

      <PdfExportModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        documentHtml={capturedHtml}
        projectName={project?.fileName}
      />
    </div>
  );
}
