import React from 'react';
import { Search, Play, ExternalLink, Square, Activity, Loader2 } from 'lucide-react';
import { LoadedProject } from '../types/runner';

interface ExecutionControlsProps {
  project: LoadedProject | null;
  loading: boolean;
  onAnalyze: () => void;
  onRun: () => void;
  onOpenApp: () => void;
  onStop: () => void;
  onTestApi?: () => void;
}

export const ExecutionControls: React.FC<ExecutionControlsProps> = ({
  project,
  loading,
  onAnalyze,
  onRun,
  onOpenApp,
  onStop,
  onTestApi,
}) => {
  const hasProject = Boolean(project);
  const isRunning = Boolean(project?.indexUrl);
  const isFullstack = project?.mode === 'fullstack';
  const isBackendRunning = Boolean(project?.backendInfo?.isRunning);

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs mb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5">
          {/* 1. Tombol Analisis Proyek */}
          <button
            onClick={onAnalyze}
            disabled={!hasProject || loading}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-800 rounded-xl text-xs sm:text-sm font-semibold border border-slate-200 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
            title="Analisis ulang struktur berkas dan dependensi tanpa melakukan build"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin text-slate-600" /> : <Search className="w-4 h-4 text-slate-600" />}
            <span>Analisis Proyek</span>
          </button>

          {/* 2. Tombol Jalankan Proyek */}
          <button
            onClick={onRun}
            disabled={!hasProject || loading}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white rounded-xl text-xs sm:text-sm font-semibold shadow-sm shadow-indigo-600/25 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
            title="Bangun frontend dan jalankan layanan proyek"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin text-white" /> : <Play className="w-4 h-4 fill-white" />}
            <span>Jalankan Proyek</span>
          </button>

          {/* 3. Tombol Buka Aplikasi */}
          <button
            onClick={onOpenApp}
            disabled={!isRunning || loading}
            className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 active:scale-98 text-emerald-800 rounded-xl text-xs sm:text-sm font-semibold border border-emerald-200 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
            title="Buka aplikasi langsung di tab browser baru"
          >
            <ExternalLink className="w-4 h-4 text-emerald-600" />
            <span>Buka Aplikasi</span>
          </button>

          {/* Tombol Uji API khusus Full-Stack */}
          {isFullstack && isBackendRunning && onTestApi && (
            <button
              onClick={onTestApi}
              disabled={loading}
              className="px-3.5 py-2 bg-purple-50 hover:bg-purple-100 active:scale-98 text-purple-800 rounded-xl text-xs sm:text-sm font-semibold border border-purple-200 transition-all flex items-center gap-1.5 cursor-pointer"
              title="Kirim request uji GET /api/health ke backend Express"
            >
              <Activity className="w-4 h-4 text-purple-600" />
              <span>Uji API</span>
            </button>
          )}
        </div>

        {/* 4. Tombol Hentikan */}
        <div>
          <button
            onClick={onStop}
            disabled={!isRunning && !isBackendRunning}
            className="px-4 py-2 bg-rose-50 hover:bg-rose-100 active:scale-98 text-rose-700 rounded-xl text-xs sm:text-sm font-semibold border border-rose-200 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
            title="Hentikan proses backend dan tutup simulasi WebView"
          >
            <Square className="w-4 h-4 text-rose-600 fill-rose-600" />
            <span>Hentikan</span>
          </button>
        </div>
      </div>
    </div>
  );
};
