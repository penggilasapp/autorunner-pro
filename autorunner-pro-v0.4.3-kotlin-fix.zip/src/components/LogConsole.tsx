import React, { useState } from 'react';
import { Terminal, Copy, Check, Trash2, Filter, AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { RunnerLogItem } from '../types/runner';

interface LogConsoleProps {
  logs: RunnerLogItem[];
  onClearLogs: () => void;
  errorDetails?: {
    title: string;
    message: string;
    logs?: string;
  } | null;
}

export const LogConsole: React.FC<LogConsoleProps> = ({ logs, onClearLogs, errorDetails }) => {
  const [filter, setFilter] = useState<'all' | 'info' | 'warn' | 'error'>('all');
  const [copied, setCopied] = useState(false);
  const [showTechnicalDetails, setShowTechnicalDetails] = useState(false);

  const filteredLogs = logs.filter((log) => {
    if (filter === 'all') return true;
    return log.level === filter;
  });

  const handleCopyLogs = () => {
    const text = logs
      .map((l) => `[${l.timestamp}] [${l.level.toUpperCase()}] [${l.source}] ${l.message}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs mb-6">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3.5 pb-2 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-indigo-600" />
          <h4 className="text-xs sm:text-sm font-bold text-slate-900 uppercase tracking-wider">
            Log Aktivitas & Konsol Diagnostik
          </h4>
          <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-mono text-[10px] font-bold">
            {logs.length} entri
          </span>
        </div>

        {/* Action Buttons & Filters */}
        <div className="flex items-center gap-2">
          {/* Level Filters */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200/80 text-[11px] font-semibold text-slate-600">
            <button
              onClick={() => setFilter('all')}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Semua
            </button>
            <button
              onClick={() => setFilter('info')}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                filter === 'info' ? 'bg-white text-blue-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Info
            </button>
            <button
              onClick={() => setFilter('warn')}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                filter === 'warn' ? 'bg-white text-amber-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Peringatan
            </button>
            <button
              onClick={() => setFilter('error')}
              className={`px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                filter === 'error' ? 'bg-white text-rose-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Error
            </button>
          </div>

          {/* Copy Button */}
          <button
            onClick={handleCopyLogs}
            disabled={logs.length === 0}
            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-40"
            title="Salin semua log ke clipboard"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
            <span className="hidden sm:inline">{copied ? 'Tersalin' : 'Salin Log'}</span>
          </button>

          {/* Clear Button */}
          <button
            onClick={onClearLogs}
            disabled={logs.length === 0}
            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer disabled:opacity-40"
            title="Bersihkan log"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Prominent Error Details Banner if error present */}
      {errorDetails && (
        <div className="mb-3.5 p-3.5 bg-rose-50 rounded-xl border border-rose-200 text-rose-950 text-xs space-y-2">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-rose-900">{errorDetails.title}</div>
              <p className="text-[11px] text-rose-700 mt-0.5 leading-relaxed">{errorDetails.message}</p>
            </div>
          </div>
          {errorDetails.logs && (
            <div>
              <button
                onClick={() => setShowTechnicalDetails(!showTechnicalDetails)}
                className="text-[11px] font-bold text-rose-800 underline hover:text-rose-900 cursor-pointer"
              >
                {showTechnicalDetails ? 'Sembunyikan Detail Teknis Stacktrace' : 'Lihat Detail Teknis Stacktrace'}
              </button>
              {showTechnicalDetails && (
                <pre className="mt-2 p-2.5 bg-slate-900 text-rose-300 font-mono text-[10px] rounded-lg max-h-48 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                  {errorDetails.logs}
                </pre>
              )}
            </div>
          )}
        </div>
      )}

      {/* Monospace Terminal Viewport (Secondary Dark Container) */}
      <div className="bg-slate-900 rounded-xl p-3 text-slate-200 font-mono text-[11px] leading-relaxed max-h-60 overflow-y-auto shadow-inner">
        {filteredLogs.length === 0 ? (
          <div className="text-slate-500 italic py-4 text-center">
            Belum ada entri log. Pilih dan jalankan proyek untuk melihat alur proses.
          </div>
        ) : (
          <div className="space-y-1">
            {filteredLogs.map((log) => (
              <div key={log.id} className="flex items-start gap-2 hover:bg-white/[0.04] p-0.5 rounded">
                <span className="text-slate-500 shrink-0 text-[10px] select-none">
                  [{log.timestamp}]
                </span>
                <span
                  className={`px-1 rounded text-[9px] font-bold shrink-0 uppercase tracking-wider ${
                    log.level === 'error'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      : log.level === 'warn'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  }`}
                >
                  {log.level}
                </span>
                <span className="text-slate-400 shrink-0 text-[10px]">
                  [{log.source}]
                </span>
                <span className="text-slate-200 break-all whitespace-pre-wrap flex-1">
                  {log.message}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
