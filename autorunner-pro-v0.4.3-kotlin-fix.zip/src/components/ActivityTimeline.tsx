import React from 'react';
import { CheckCircle2, Circle, Loader2, MinusCircle, XCircle } from 'lucide-react';
import { ActivityStep } from '../types/runner';

interface ActivityTimelineProps {
  steps?: ActivityStep[];
}

export const ActivityTimeline: React.FC<ActivityTimelineProps> = ({ steps }) => {
  const defaultSteps: ActivityStep[] = [
    { id: '1_structure', title: 'Memeriksa struktur proyek', status: 'pending' },
    { id: '2_dependencies', title: 'Menyiapkan dependensi', status: 'pending' },
    { id: '3_build', title: 'Membangun frontend', status: 'pending' },
    { id: '4_backend', title: 'Memulai backend', status: 'pending' },
    { id: '5_server_ready', title: 'Memeriksa kesiapan server', status: 'pending' },
    { id: '6_launch', title: 'Membuka aplikasi', status: 'pending' },
  ];

  const currentSteps = steps && steps.length > 0 ? steps : defaultSteps;

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs mb-6">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
        <h4 className="text-xs sm:text-sm font-bold text-slate-900 uppercase tracking-wider">
          Tahapan Eksekusi (Activity Timeline)
        </h4>
        <span className="text-[11px] text-slate-500">Alur Otomatis Runner</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {currentSteps.map((step, idx) => {
          let badgeBg = 'bg-slate-50 border-slate-200/80 text-slate-600';
          let icon = <Circle className="w-4 h-4 text-slate-400" />;
          let statusLabel = 'Menunggu';

          if (step.status === 'running') {
            badgeBg = 'bg-blue-50 border-blue-200 text-blue-900';
            icon = <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />;
            statusLabel = 'Sedang Berjalan';
          } else if (step.status === 'success') {
            badgeBg = 'bg-emerald-50 border-emerald-200 text-emerald-950';
            icon = <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />;
            statusLabel = 'Selesai';
          } else if (step.status === 'skipped') {
            badgeBg = 'bg-slate-50/60 border-slate-200/50 text-slate-500';
            icon = <MinusCircle className="w-4 h-4 text-slate-400 shrink-0" />;
            statusLabel = 'Tidak Diperlukan';
          } else if (step.status === 'failed') {
            badgeBg = 'bg-rose-50 border-rose-200 text-rose-950';
            icon = <XCircle className="w-4 h-4 text-rose-600 shrink-0" />;
            statusLabel = 'Gagal';
          }

          return (
            <div
              key={step.id || idx}
              className={`p-3 rounded-xl border ${badgeBg} flex items-start gap-2.5 transition-all duration-150`}
            >
              <div className="mt-0.5 shrink-0">{icon}</div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1 mb-0.5">
                  <span className="text-xs font-bold leading-tight truncate">
                    {idx + 1}. {step.title}
                  </span>
                  <span className="text-[10px] font-semibold shrink-0 uppercase tracking-wider">
                    {statusLabel}
                  </span>
                </div>
                {step.message && (
                  <p className="text-[11px] opacity-80 leading-snug truncate" title={step.message}>
                    {step.message}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
