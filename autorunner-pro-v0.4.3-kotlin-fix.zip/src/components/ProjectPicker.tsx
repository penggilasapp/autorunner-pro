import React from 'react';
import { FolderOpen, FileArchive, RefreshCw, CheckCircle2, FileCode, Layers, Server, Code } from 'lucide-react';
import { LoadedProject } from '../types/runner';

interface ProjectPickerProps {
  project: LoadedProject | null;
  onOpenFolderPicker: () => void;
  onOpenFilePicker: () => void;
  onOpenPasteCode: () => void;
  onResetProject: () => void;
  loading: boolean;
}

export const ProjectPicker: React.FC<ProjectPickerProps> = ({
  project,
  onOpenFolderPicker,
  onOpenFilePicker,
  onOpenPasteCode,
  onResetProject,
  loading,
}) => {
  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs mb-6">
      {!project ? (
        <div className="flex flex-col items-center text-center">
          {/* Prominent Folder Icon */}
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 mb-4 shadow-xs">
            <FolderOpen className="w-8 h-8" />
          </div>

          <h3 className="text-lg font-bold text-slate-900 tracking-tight">
            Pilih Folder Proyek atau Berkas ZIP
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 max-w-lg mt-1 mb-5 leading-relaxed">
            Pilih direktori proyek hasil ekstraksi di HP/komputer atau berkas ZIP. Runner akan menganalisis struktur, menyiapkan dependensi, dan menjalankan aplikasi.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 w-full max-w-md">
            <button
              onClick={onOpenFolderPicker}
              disabled={loading}
              className="flex-1 min-w-[160px] py-3 px-4 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white rounded-xl text-xs sm:text-sm font-semibold shadow-sm shadow-indigo-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <FolderOpen className="w-4 h-4" />
              <span>Pilih Folder Proyek</span>
            </button>

            <button
              onClick={onOpenFilePicker}
              disabled={loading}
              className="flex-1 min-w-[140px] py-3 px-4 bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-800 rounded-xl text-xs sm:text-sm font-semibold border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <FileArchive className="w-4 h-4 text-slate-600" />
              <span>Pilih ZIP</span>
            </button>

            <button
              onClick={onOpenPasteCode}
              disabled={loading}
              className="py-3 px-3.5 bg-slate-50 hover:bg-slate-100 active:scale-98 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              title="Tempel kode HTML langsung"
            >
              <Code className="w-4 h-4 text-amber-600" />
              <span>Tempel Kode</span>
            </button>
          </div>

          {/* Supported Format Guide */}
          <div className="mt-6 pt-5 border-t border-slate-100 w-full grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-left">
            <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[11px] font-bold text-slate-900 flex items-center gap-1 mb-0.5">
                <FileCode className="w-3.5 h-3.5 text-emerald-600" />
                <span>1. Web Statis</span>
              </div>
              <p className="text-[10px] text-slate-500">HTML, CSS, JS tanpa build step.</p>
            </div>

            <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[11px] font-bold text-slate-900 flex items-center gap-1 mb-0.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                <span>2. Pre-built Web</span>
              </div>
              <p className="text-[10px] text-slate-500">Folder dist/ siap pakai.</p>
            </div>

            <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[11px] font-bold text-slate-900 flex items-center gap-1 mb-0.5">
                <Layers className="w-3.5 h-3.5 text-blue-600" />
                <span>3. Source Vite</span>
              </div>
              <p className="text-[10px] text-slate-500">React, TypeScript, JSX mentah.</p>
            </div>

            <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[11px] font-bold text-slate-900 flex items-center gap-1 mb-0.5">
                <Server className="w-3.5 h-3.5 text-purple-600" />
                <span>4. Full-Stack</span>
              </div>
              <p className="text-[10px] text-slate-500">Vite frontend + Express API.</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
              <FolderOpen className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-sm sm:text-base truncate">
                  {project.fileName}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                  Terpilih
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {project.entryCount} berkas • {Math.round(project.fileSize / 1024)} KB • Halaman: <code className="text-indigo-600 font-mono font-semibold">{project.startPage}</code>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onResetProject}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Ganti Proyek</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
