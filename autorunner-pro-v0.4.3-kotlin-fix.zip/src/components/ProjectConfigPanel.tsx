import React from 'react';
import {
  Layers,
  Server,
  FileCode,
  Package,
  Cpu,
  CheckCircle2,
  Clock,
  Info,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { LoadedProject } from '../types/runner';

interface ProjectConfigPanelProps {
  project: LoadedProject | null;
}

export const ProjectConfigPanel: React.FC<ProjectConfigPanelProps> = ({ project }) => {
  if (!project) return null;

  const analysis = project.analysis;
  const mode = project.mode || 'static';
  const buildValidation = project.buildValidation;
  const backend = project.backendInfo;

  return (
    <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs mb-6">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-indigo-600" />
          <h4 className="text-xs sm:text-sm font-bold text-slate-900 uppercase tracking-wider">
            Deteksi & Konfigurasi Proyek
          </h4>
        </div>
        <span className="text-[11px] text-slate-500">
          Node {process.version || 'v22.x'} • Base Path Relatif <code>./</code>
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* 1. Jenis Proyek & Alasan */}
        <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60 flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Jenis Terdeteksi
            </span>
            <div className="flex items-center gap-1.5 mb-1.5">
              {mode === 'fullstack' ? (
                <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 text-xs font-bold border border-purple-200">
                  Full-Stack Express
                </span>
              ) : mode === 'vite-react' ? (
                <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-xs font-bold border border-blue-200">
                  React + Vite SPA
                </span>
              ) : mode === 'prebuilt' ? (
                <span className="px-2 py-0.5 rounded-md bg-teal-100 text-teal-800 text-xs font-bold border border-teal-200">
                  Pre-built Web
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200">
                  Static Website
                </span>
              )}
            </div>
          </div>
          <p className="text-[11px] text-slate-600 leading-snug">
            {analysis?.reason || 'Proyek web statis standar.'}
          </p>
        </div>

        {/* 2. Package Manager & Lockfile */}
        <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60 flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Package Manager & Lockfile
            </span>
            <div className="flex items-center gap-1.5 mb-1.5">
              <span className="px-2 py-0.5 rounded-md bg-slate-200/80 text-slate-800 font-mono text-xs font-bold">
                {analysis?.packageManager && analysis.packageManager !== 'none' ? analysis.packageManager : 'N/A (Statis)'}
              </span>
              {analysis?.lockfile && (
                <span className="px-1.5 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 font-mono text-[10px] font-semibold">
                  {analysis.lockfile}
                </span>
              )}
            </div>
          </div>
          <p className="text-[11px] text-slate-600 leading-snug">
            {analysis?.lockfile
              ? `Lockfile terdeteksi: instalasi divalidasi presisi.`
              : 'Tidak ada lockfile eksternal yang diwajibkan.'}
          </p>
        </div>

        {/* 3. Status Build Frontend */}
        <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60 flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Kompilasi Frontend
            </span>
            <div className="flex items-center gap-1.5 mb-1.5">
              {buildValidation?.status === 'SUCCESS' || buildValidation?.success ? (
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>Selesai ({buildValidation.durationMs}ms)</span>
                </span>
              ) : mode === 'static' ? (
                <span className="px-2 py-0.5 rounded-md bg-slate-200/80 text-slate-700 text-xs font-semibold">
                  Tanpa Kompilasi
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-xs font-semibold">
                  Siap Dijalankan
                </span>
              )}
            </div>
          </div>
          <p className="text-[11px] text-slate-600 leading-snug">
            {buildValidation
              ? `${buildValidation.verifiedFilesCount} berkas, ${Math.round(buildValidation.totalAssetBytes / 1024)} KB aset.`
              : 'Frontend siap disajikan langsung ke WebView.'}
          </p>
        </div>

        {/* 4. Status Backend Express */}
        <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200/60 flex flex-col justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Layanan Backend
            </span>
            <div className="flex items-center gap-1.5 mb-1.5">
              {backend?.isRunning ? (
                <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 text-xs font-bold border border-purple-200 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-600 animate-pulse"></span>
                  <span>Port {backend.port}</span>
                </span>
              ) : mode === 'fullstack' ? (
                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-xs font-semibold">
                  Belum Berjalan
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-md bg-slate-200/80 text-slate-600 text-xs font-semibold">
                  Tidak Ada Backend
                </span>
              )}
            </div>
          </div>
          <p className="text-[11px] text-slate-600 leading-snug">
            {backend?.isRunning
              ? `PID ${backend.pid} • Reverse proxy otomatis aktif.`
              : mode === 'fullstack'
              ? 'Tekan tombol Jalankan untuk mengaktifkan Express.'
              : 'Aplikasi berjalan murni di sisi klien.'}
          </p>
        </div>
      </div>
    </div>
  );
};
