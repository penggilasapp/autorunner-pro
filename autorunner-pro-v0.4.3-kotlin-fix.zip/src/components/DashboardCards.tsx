import React from 'react';
import { Folder, Layers, Server, Cpu, CheckCircle2, AlertCircle, Clock } from 'lucide-react';
import { LoadedProject } from '../types/runner';

interface DashboardCardsProps {
  project: LoadedProject | null;
  isRunning: boolean;
}

export const DashboardCards: React.FC<DashboardCardsProps> = ({ project, isRunning }) => {
  const mode = project?.mode || (project ? 'static' : null);
  const backend = project?.backendInfo;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 w-full mb-6">
      {/* 1. Proyek Aktif */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
            Proyek Aktif
          </span>
          <div className="w-7 h-7 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
            <Folder className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <div className="text-sm sm:text-base font-bold text-slate-900 truncate" title={project?.fileName || 'Belum dipilih'}>
            {project?.fileName || 'Tidak Ada Proyek'}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5 truncate">
            {project ? `${project.entryCount} berkas • ${Math.round(project.fileSize / 1024)} KB` : 'Pilih folder atau ZIP di bawah'}
          </p>
        </div>
      </div>

      {/* 2. Mode Proyek */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
            Mode Proyek
          </span>
          <div className="w-7 h-7 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600">
            <Layers className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <div className="text-sm sm:text-base font-bold text-slate-900">
            {mode === 'fullstack' ? (
              <span className="text-purple-600">Full-Stack App</span>
            ) : mode === 'vite-react' ? (
              <span className="text-blue-600">React + Vite SPA</span>
            ) : mode === 'prebuilt' ? (
              <span className="text-teal-600">Pre-built Web</span>
            ) : mode === 'static' ? (
              <span className="text-emerald-600">Static Website</span>
            ) : (
              <span className="text-slate-400">Menunggu Input</span>
            )}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5 truncate">
            {project?.analysis?.packageManager ? `PM: ${project.analysis.packageManager}` : 'Analisis otomatis'}
          </p>
        </div>
      </div>

      {/* 3. Status Runtime */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
            Status Runtime
          </span>
          <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
            <Cpu className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <div className="flex items-center gap-1.5 text-sm sm:text-base font-bold text-slate-900">
            <span className={`w-2 h-2 rounded-full ${project?.isCompiled || project ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
            <span>{project?.isCompiled ? 'Siap / Terkompilasi' : project ? 'Aktif' : 'Standby'}</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Node {process.version || 'v22.x'} • Base: <code>./</code>
          </p>
        </div>
      </div>

      {/* 4. Status Server Backend */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
            Status Server & API
          </span>
          <div className="w-7 h-7 rounded-lg bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
            <Server className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <div className="text-sm sm:text-base font-bold text-slate-900">
            {backend?.isRunning ? (
              <span className="text-emerald-600 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Port {backend.port} (Aktif)</span>
              </span>
            ) : mode === 'fullstack' ? (
              <span className="text-amber-600">Menunggu Start</span>
            ) : (
              <span className="text-slate-400">Tidak Diperlukan</span>
            )}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5 truncate">
            {backend?.isRunning ? `PID: ${backend.pid} • Reverse Proxy Aktif` : 'Frontend Client-Side'}
          </p>
        </div>
      </div>
    </div>
  );
};
