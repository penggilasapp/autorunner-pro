import React from 'react';
import { Layers, Terminal, Download, ShieldCheck, Sun, Moon, ExternalLink } from 'lucide-react';

interface HeaderProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenAutomation: () => void;
  activeProjectName?: string;
  projectId?: string;
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  onToggleDarkMode,
  onOpenAutomation,
  activeProjectName,
  projectId,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 px-4 sm:px-6 py-3 shadow-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center text-white shadow-sm shadow-indigo-500/25 shrink-0">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-slate-900 tracking-tight text-base sm:text-lg">
                PENGGILAS ZIP RUNNER
              </span>
              <span className="px-1.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 text-[10px] font-black border border-indigo-200 tracking-wide">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-slate-500 hidden sm:block">
              Universal Project Runner & Android WebView Environment
            </p>
          </div>
        </div>

        {/* Runtime Status & Actions */}
        <div className="flex items-center gap-2.5">
          {/* Runtime pill */}
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 bg-slate-100/90 text-slate-700 rounded-lg text-xs font-medium border border-slate-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Node {process.version || 'v22'} • Engine Siap</span>
          </div>

          {/* Automation script guide */}
          <button
            onClick={onOpenAutomation}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Lihat skrip integrasi Android SDK & build-tools"
          >
            <Terminal className="w-3.5 h-3.5 text-indigo-600" />
            <span className="hidden sm:inline">Skrip Otomasi</span>
          </button>

          {/* Android Template Download */}
          <a
            href={projectId ? `/api/download-project/${projectId}` : "/assets/PENGGILAS-ZIP-RUNNER-ANDROID-v2.0-PRO.zip"}
            download={projectId ? `${activeProjectName || 'project'}-android-ready.zip` : "PENGGILAS-ZIP-RUNNER-ANDROID-v2.0-PRO.zip"}
            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            title={projectId ? "Unduh paket web hasil kompilasi siap pasang di WebView" : "Unduh source Android Kotlin template"}
          >
            <Download className="w-3.5 h-3.5" />
            <span>{projectId ? 'Unduh Web ZIP' : 'Unduh Android'}</span>
          </a>

          {/* Theme Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            title={darkMode ? "Ganti ke Tema Terang (Default)" : "Ganti ke Tema Gelap"}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
