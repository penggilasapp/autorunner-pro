import React, { useRef, useEffect, useState } from 'react';
import {
  RotateCw,
  Maximize2,
  Minimize2,
  RefreshCw,
  Printer,
  ChevronLeft,
  Square,
  Circle,
  Eye,
  EyeOff,
  ExternalLink,
  Smartphone,
  Layers,
  Sparkles,
  Upload,
  FolderOpen,
  Code
} from 'lucide-react';
import { LoadedProject, PhoneSettings } from '../types/runner';

interface PhoneSimulatorProps {
  project: LoadedProject | null;
  settings: PhoneSettings;
  onUpdateSettings: (newSettings: Partial<PhoneSettings>) => void;
  onPrintRequest: () => void;
  onOpenFiles: () => void;
  onCloseProject: () => void;
  onOpenFilePicker?: () => void;
  onOpenFolderPicker?: () => void;
  onOpenPasteCode?: () => void;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  project,
  settings,
  onUpdateSettings,
  onPrintRequest,
  onOpenFiles,
  onCloseProject,
  onOpenFilePicker,
  onOpenFolderPicker,
  onOpenPasteCode,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentTime, setCurrentTime] = useState<string>('09:41');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [viewportWidth, setViewportWidth] = useState<number>(typeof window !== 'undefined' ? window.innerWidth : 1200);

  useEffect(() => {
    const handleResize = () => setViewportWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateClock();
    const interval = setInterval(updateClock, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const toggleBrowserFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        if (containerRef.current) {
          await containerRef.current.requestFullscreen();
          onUpdateSettings({ immersiveMode: true });
        }
      } else {
        await document.exitFullscreen();
      }
    } catch (e) {
      console.warn('Fullscreen error', e);
    }
  };

  const reloadIframe = () => {
    if (iframeRef.current && project?.indexUrl) {
      iframeRef.current.src = project.indexUrl;
    }
  };

  const handleAndroidBack = () => {
    try {
      if (iframeRef.current?.contentWindow) {
        iframeRef.current.contentWindow.history.back();
      }
    } catch (_e) {
      onCloseProject();
    }
  };

  const handleOpenExternal = () => {
    if (project?.indexUrl) {
      window.open(project.indexUrl, '_blank', 'noopener,noreferrer');
    }
  };

  // Dimensions based on device and screen size
  const getDeviceDimensions = () => {
    const isMobileScreen = viewportWidth < 640;

    if (settings.isLandscape) {
      switch (settings.deviceType) {
        case 'tablet':
          return { width: isMobileScreen ? '100%' : '840px', height: isMobileScreen ? '360px' : '540px' };
        case 'compact-phone':
          return { width: isMobileScreen ? '100%' : '660px', height: isMobileScreen ? '320px' : '360px' };
        default:
          return { width: isMobileScreen ? '100%' : '740px', height: isMobileScreen ? '340px' : '390px' };
      }
    } else {
      switch (settings.deviceType) {
        case 'tablet':
          return { width: isMobileScreen ? '100%' : '540px', height: isMobileScreen ? '580px' : '760px' };
        case 'compact-phone':
          return { width: isMobileScreen ? '100%' : '350px', height: isMobileScreen ? '560px' : '660px' };
        default:
          return { width: isMobileScreen ? '100%' : '395px', height: isMobileScreen ? '620px' : '780px' };
      }
    }
  };

  const isMobileScreen = viewportWidth < 640;
  const dimensions = getDeviceDimensions();
  const showFrame = settings.showDeviceFrame !== false && !isFullscreen;

  return (
    <div
      ref={containerRef}
      className={`relative flex flex-col items-center justify-center transition-all duration-300 w-full ${
        isFullscreen ? 'bg-black w-screen h-screen p-0 fixed inset-0 z-50' : 'py-2 px-2 sm:px-4'
      }`}
    >
      {/* Control Toolbar atop Phone */}
      {!isFullscreen && (
        <div className="w-full max-w-2xl mb-3 sm:mb-4 px-2 overflow-x-auto no-scrollbar flex sm:justify-center">
          <div className="flex items-center gap-1 sm:gap-1.5 p-1 sm:p-1.5 bg-white border border-slate-200/90 rounded-2xl shadow-sm text-xs text-slate-700 shrink-0">
            {/* Device Profile Selector */}
            <div className="flex items-center gap-1.5 px-2 py-1 border-r border-slate-200 shrink-0">
              <Smartphone className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <select
                value={settings.deviceType}
                onChange={(e) => onUpdateSettings({ deviceType: e.target.value as PhoneSettings['deviceType'] })}
                aria-label="Pilih tipe perangkat HP"
                className="bg-transparent text-slate-800 text-xs font-semibold focus:outline-none cursor-pointer"
              >
                <option value="android-flagship">6.7" Flagship</option>
                <option value="compact-phone">6.1" Compact</option>
                <option value="tablet">10" Tablet</option>
              </select>
            </div>

            {/* Toggle Frame vs Edge-to-Edge */}
            <button
              onClick={() => onUpdateSettings({ showDeviceFrame: !showFrame })}
              className={`p-1.5 rounded-xl transition-all flex items-center gap-1 shrink-0 ${
                !showFrame ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-200' : 'hover:bg-slate-100 text-slate-700'
              }`}
              title={showFrame ? "Ubah ke Mode Layar Penuh HP Tanpa Bezel" : "Tampilkan Bingkai Ponsel"}
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{showFrame ? 'Bingkai' : 'Edge-to-Edge'}</span>
            </button>

            {/* Rotate Orientation */}
            <button
              onClick={() => onUpdateSettings({ isLandscape: !settings.isLandscape })}
              className="p-1.5 hover:bg-slate-100 rounded-xl text-slate-700 transition-all flex items-center gap-1 shrink-0"
              title="Putar Orientasi Layar (Landscape / Portrait)"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{settings.isLandscape ? 'Landscape' : 'Portrait'}</span>
            </button>

            {/* Toggle Immersive Mode */}
            <button
              onClick={() => onUpdateSettings({ immersiveMode: !settings.immersiveMode })}
              className={`p-1.5 rounded-xl transition-all flex items-center gap-1 shrink-0 font-medium ${
                settings.immersiveMode ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : 'hover:bg-slate-100 text-slate-700'
              }`}
              title="Mode Immersive Layar Penuh (Sembunyikan Status & Navigasi Bar)"
            >
              {settings.immersiveMode ? <EyeOff className="w-3.5 h-3.5 text-indigo-600" /> : <Eye className="w-3.5 h-3.5 text-slate-400" />}
              <span className="hidden md:inline">Immersive</span>
            </button>

            {/* Reload Webview */}
            <button
              onClick={reloadIframe}
              className="p-1.5 hover:bg-slate-100 rounded-xl text-slate-700 transition-all shrink-0 cursor-pointer"
              title="Muat Ulang Halaman (Reload)"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>

            {/* Print & PDF */}
            <button
              onClick={onPrintRequest}
              className="p-1.5 hover:bg-indigo-50 text-indigo-700 rounded-xl transition-all flex items-center gap-1 shrink-0 font-semibold cursor-pointer"
              title="Cetak & Unduh Laporan PDF"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">Cetak</span>
            </button>

            {/* Open in External Tab */}
            {project?.indexUrl && (
              <button
                onClick={handleOpenExternal}
                className="p-1.5 hover:bg-slate-100 rounded-xl text-slate-700 transition-all shrink-0 hidden sm:flex items-center gap-1 cursor-pointer"
                title="Buka di Tab Browser Baru"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Fullscreen Modal Toggle */}
            <button
              onClick={toggleBrowserFullscreen}
              className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition-all flex items-center gap-1 font-semibold ml-0.5 shrink-0 shadow-xs cursor-pointer"
              title="Layar Penuh Simulator"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Fullscreen</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Exit Button in Fullscreen mode */}
      {isFullscreen && (
        <div className="absolute top-4 right-4 z-50 flex items-center gap-2">
          <button
            onClick={onPrintRequest}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full text-xs font-semibold shadow-lg flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Cetak PDF
          </button>
          <button
            onClick={toggleBrowserFullscreen}
            className="px-3.5 py-1.5 bg-white/90 hover:bg-white text-slate-800 rounded-full text-xs font-semibold shadow-lg border border-slate-200 flex items-center gap-1.5 cursor-pointer"
          >
            <Minimize2 className="w-3.5 h-3.5" />
            Keluar Fullscreen
          </button>
        </div>
      )}

      {/* Phone Frame or Edge-to-Edge Container */}
      <div
        style={{
          width: isFullscreen ? '100vw' : showFrame ? dimensions.width : '100%',
          maxWidth: isFullscreen ? '100vw' : showFrame ? dimensions.width : isMobileScreen ? '100%' : '720px',
          height: isFullscreen ? '100vh' : !showFrame && isMobileScreen ? 'calc(100dvh - 120px)' : dimensions.height,
          maxHeight: isFullscreen ? '100vh' : !showFrame && isMobileScreen ? 'calc(100dvh - 120px)' : 'calc(100vh - 170px)',
        }}
        className={`relative transition-all duration-300 flex flex-col overflow-hidden ${
          isFullscreen
            ? 'rounded-none border-0 shadow-none bg-black'
            : showFrame
            ? 'rounded-[44px] border-[10px] sm:border-[12px] border-slate-900 bg-slate-900 shadow-2xl ring-1 ring-slate-800/80'
            : isMobileScreen
            ? 'rounded-xl border border-slate-300 bg-white shadow-md w-full'
            : 'rounded-2xl border border-slate-300 bg-white shadow-lg'
        }`}
      >
        {/* Notch (Only if not immersive and frame is active) */}
        {!settings.immersiveMode && showFrame && !isFullscreen && !settings.isLandscape && (
          <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-28 h-4.5 bg-black rounded-full z-40 flex items-center justify-between px-3 pointer-events-none ring-1 ring-white/10">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-900 ring-1 ring-slate-800 flex items-center justify-center">
              <div className="w-1 h-1 rounded-full bg-blue-400/80"></div>
            </div>
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"></div>
          </div>
        )}

        {/* Mobile Status Bar (Hidden in Immersive Mode) */}
        {!settings.immersiveMode && (
          <div className="h-7 w-full bg-slate-900 text-white flex items-center justify-between px-5 text-[11px] font-medium tracking-tight select-none z-30 shrink-0 border-b border-white/[0.04]">
            <span className="text-slate-300 font-medium">{currentTime}</span>
            <div className="flex items-center gap-2 text-slate-300 text-[10px]">
              <span className="font-semibold text-emerald-400/90">5G</span>
              <div className="flex items-end gap-0.5 h-2.5">
                <div className="w-0.5 h-1 bg-white/80 rounded-xs"></div>
                <div className="w-0.5 h-1.5 bg-white/80 rounded-xs"></div>
                <div className="w-0.5 h-2 bg-white/80 rounded-xs"></div>
                <div className="w-0.5 h-2.5 bg-white/80 rounded-xs"></div>
              </div>
              <div className="w-4 h-2.5 border border-white/80 rounded-xs p-0.5 flex items-center">
                <div className="h-full w-3/4 bg-white/90 rounded-xs"></div>
              </div>
            </div>
          </div>
        )}

        {/* Simulated Web Viewport (100% in immersive mode) */}
        <div className="relative flex-1 w-full bg-white overflow-hidden">
          {project ? (
            <iframe
              ref={iframeRef}
              src={project.indexUrl}
              title={project.fileName}
              className="w-full h-full border-0 select-auto block bg-white"
              allow="camera; microphone; geolocation; fullscreen; clipboard-read; clipboard-write;"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-top-navigation-by-user-activation"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-slate-50 text-slate-600 relative overflow-hidden">
              <div className="w-14 h-14 rounded-2xl bg-white border border-slate-200 flex items-center justify-center mb-3 shadow-xs text-indigo-600">
                <Smartphone className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 mb-1">Simulator WebView Siap</h3>
              <p className="text-xs text-slate-500 max-w-xs mb-4 leading-relaxed">
                Pilih folder proyek atau ZIP untuk mulai menjalankan aplikasi di layar WebView.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={onOpenFolderPicker}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition cursor-pointer"
                >
                  Pilih Folder
                </button>
                <button
                  onClick={onOpenFilePicker}
                  className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold transition cursor-pointer"
                >
                  Pilih ZIP
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Android Navigation Bar (Hidden in Immersive Mode) */}
        {!settings.immersiveMode && (
          <div className="h-8 w-full bg-slate-900 flex items-center justify-around px-8 text-slate-400 select-none z-30 shrink-0 border-t border-white/[0.04]">
            <button
              onClick={handleAndroidBack}
              className="p-2 hover:text-white transition cursor-pointer"
              title="Android Back Button"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={reloadIframe}
              className="p-2 hover:text-white transition cursor-pointer"
              title="Android Home Button"
            >
              <Circle className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onOpenFiles}
              className="p-2 hover:text-white transition cursor-pointer"
              title="Android Recents Button"
            >
              <Square className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Immersive quick toggle tab */}
        {settings.immersiveMode && !isFullscreen && (
          <button
            onClick={() => onUpdateSettings({ immersiveMode: false })}
            className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-28 h-1 bg-slate-400/40 hover:bg-slate-400/80 rounded-full transition-all duration-200 z-50 cursor-pointer"
            title="Klik untuk memunculkan kembali bilah status & navigasi HP"
          />
        )}
      </div>
    </div>
  );
};
