export type ExecutionMode = 'static' | 'prebuilt' | 'vite-react' | 'fullstack' | 'unsupported';

export interface ZipFileEntry {
  name: string;
  size: number;
  compressedSize: number;
  isDirectory: boolean;
  blob?: Blob;
  url?: string;
  mimeType: string;
}

export interface ProjectAnalysis {
  mode: ExecutionMode;
  reason: string;
  packageManager: 'npm' | 'bun' | 'yarn' | 'pnpm' | 'none';
  lockfile: string | null;
  dependencies: Record<string, string>;
  devDependencies: Record<string, string>;
  scripts: Record<string, string>;
  hasServerFile: boolean;
  serverFile: string | null;
  entryHtml: string | null;
  runtimeVersion: string;
  isPrebuilt?: boolean;
}

export interface BuildValidation {
  status: 'SUCCESS' | 'FAILED' | 'SKIPPED';
  success?: boolean;
  durationMs: number;
  verifiedFilesCount: number;
  assetCount: number;
  totalAssetBytes: number;
  hasIndexHtml: boolean;
  entryHtmlSize: number;
  logs?: string;
  error?: string | null;
}

export interface BackendProcessInfo {
  isRunning: boolean;
  pid: number | null;
  port: number | null;
  statusText: string;
  healthStatus: 'HEALTHY' | 'UNHEALTHY' | 'STOPPED' | 'NOT_APPLICABLE';
  healthUrl: string | null;
  recentLogs: string[];
}

export type StepStatus = 'pending' | 'running' | 'success' | 'skipped' | 'failed';

export interface ActivityStep {
  id: string;
  title: string;
  status: StepStatus;
  message?: string;
}

export interface RunnerLogItem {
  id: string;
  level: 'info' | 'warn' | 'error';
  message: string;
  timestamp: string;
  source: 'engine' | 'build' | 'backend' | 'webview';
}

export interface LoadedProject {
  fileName: string;
  fileSize: number;
  entryCount: number;
  startPage: string;
  entries: Map<string, ZipFileEntry>;
  indexUrl: string;
  loadedAt: Date;
  rawZipBlob: Blob;
  projectId?: string;
  mode?: ExecutionMode;
  isCompiled?: boolean;
  analysis?: ProjectAnalysis;
  buildValidation?: BuildValidation;
  backendInfo?: BackendProcessInfo;
  activitySteps?: ActivityStep[];
  errorDetails?: {
    title: string;
    message: string;
    logs?: string;
  } | null;
}

export interface PhoneSettings {
  deviceType: 'android-flagship' | 'compact-phone' | 'tablet';
  isLandscape: boolean;
  immersiveMode: boolean; // hide status bar and nav bar
  showDeviceFrame: boolean;
  autoFullscreenOnZip: boolean;
  autoInjectDependencies: boolean;
  networkOffline: boolean;
}

export interface ReportConfig {
  title: string;
  subtitle: string;
  pageSize: 'a4' | 'letter' | 'receipt-80mm';
  orientation: 'portrait' | 'landscape';
  includeHeader: boolean;
  includeFooter: boolean;
  themeColor: string;
}
